#ifndef PRINTIT
#define PRINTIT

/************************** PRINT.H ******************************
*
*  Written by Mikeyg
*/
#include "../../klog/klog.h"
extern void print (int device, char *str);

/***************************************************************/

#endif
