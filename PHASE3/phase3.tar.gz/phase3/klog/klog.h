#ifndef KLOG_H
#define KLOG_H

void klog_print(char *str);
void klog_print_hex(unsigned int num);

#endif /*KLOG_H*/

