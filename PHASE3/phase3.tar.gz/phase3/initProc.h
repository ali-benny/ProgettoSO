#ifndef INIT_PROC
#define INIT_PROC

#include "pandos_const.h"
#include "pandos_types.h"
#include "vmSupport.h"
#include "sysSupport.h"

void test(); 

#endif //INIT_PROC