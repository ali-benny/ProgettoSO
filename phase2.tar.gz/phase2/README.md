# Progetto di Sistemi Operativi
## realizzato da: alice, alberto(detto Betto), gerald, libera.

Vedi DOCUMENTAZIONE.pdf

